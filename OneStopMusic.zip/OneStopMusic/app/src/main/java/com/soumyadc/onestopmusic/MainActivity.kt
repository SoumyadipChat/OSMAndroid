package com.soumyadc.onestopmusic

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.view.View
import android.widget.SeekBar


class MainActivity : Activity() {


    private lateinit var webView: WebView
    private lateinit var seekbar: SeekBar
    private lateinit var webSettings: WebSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webviewid)
        webSettings = webView.getSettings()
        webView.setWebChromeClient(WebChromeClient())
        webSettings.setDomStorageEnabled(true)
        webSettings.setAppCacheEnabled(true)
        webSettings.setJavaScriptEnabled(true)
        webSettings.setMediaPlaybackRequiresUserGesture(false)
        webView.loadUrl("https://soumyadipchat.github.io")
    }

    fun sendNotification(view:View){

    }
}
